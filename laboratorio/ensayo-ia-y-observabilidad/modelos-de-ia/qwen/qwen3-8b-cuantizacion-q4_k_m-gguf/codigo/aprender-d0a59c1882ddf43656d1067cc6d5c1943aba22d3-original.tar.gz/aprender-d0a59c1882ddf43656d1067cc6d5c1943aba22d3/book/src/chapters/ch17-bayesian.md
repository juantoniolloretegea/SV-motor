<!-- PCU: ch17-bayesian | contract: contracts/apr-book-ch17-v1.yaml -->
<!-- Example: cargo run -p aprender-core --example ch17_bayesian -->
<!-- Status: enforced -->

# Chapter 17: Bayesian Methods

> Contract: [`apr-book-ch17`](../../../contracts/apr-book-ch17-v1.yaml)

Run: `cargo run -p aprender-core --example ch17_bayesian`

```rust,ignore
{{#include ../../../crates/aprender-core/examples/ch17_bayesian.rs}}
```
