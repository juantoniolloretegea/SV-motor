<!-- PCU: lib-recommend | contract: contracts/apr-page-lib-recommend-v1.yaml -->

# Module: `aprender::recommend`

Public module of the `aprender-core` crate.

## Source

[`crates/aprender-core/src/recommend.rs`](https://github.com/paiml/aprender/blob/main/crates/aprender-core/src/recommend.rs) or directory.

## Example

<!-- example-cost: trivial -->
```rust
use aprender::recommend;
// See `cargo doc -p aprender-core --open` for full API reference.
```

## Full API

Run `cargo doc -p aprender-core --open` for the rendered rustdoc, or browse
[docs.rs/aprender](https://docs.rs/aprender) for the published version.
