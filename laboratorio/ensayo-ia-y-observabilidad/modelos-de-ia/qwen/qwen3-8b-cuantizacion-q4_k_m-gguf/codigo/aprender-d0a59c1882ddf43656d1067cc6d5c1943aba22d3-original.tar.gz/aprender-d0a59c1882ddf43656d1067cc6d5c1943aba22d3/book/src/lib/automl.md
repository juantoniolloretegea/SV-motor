<!-- PCU: lib-automl | contract: contracts/apr-page-lib-automl-v1.yaml -->

# Module: `aprender::automl`

Public module of the `aprender-core` crate.

## Source

[`crates/aprender-core/src/automl.rs`](https://github.com/paiml/aprender/blob/main/crates/aprender-core/src/automl.rs) or directory.

## Example

<!-- example-cost: trivial -->
```rust
use aprender::automl;
// See `cargo doc -p aprender-core --open` for full API reference.
```

## Full API

Run `cargo doc -p aprender-core --open` for the rendered rustdoc, or browse
[docs.rs/aprender](https://docs.rs/aprender) for the published version.
