<!-- PCU: lib-demo | contract: contracts/apr-page-lib-demo-v1.yaml -->

# Module: `aprender::demo`

Public module of the `aprender-core` crate.

## Source

[`crates/aprender-core/src/demo.rs`](https://github.com/paiml/aprender/blob/main/crates/aprender-core/src/demo.rs) or directory.

## Example

<!-- example-cost: trivial -->
```rust
use aprender::demo;
// See `cargo doc -p aprender-core --open` for full API reference.
```

## Full API

Run `cargo doc -p aprender-core --open` for the rendered rustdoc, or browse
[docs.rs/aprender](https://docs.rs/aprender) for the published version.
