<!-- PCU: lib-bundle | contract: contracts/apr-page-lib-bundle-v1.yaml -->

# Module: `aprender::bundle`

Public module of the `aprender-core` crate.

## Source

[`crates/aprender-core/src/bundle.rs`](https://github.com/paiml/aprender/blob/main/crates/aprender-core/src/bundle.rs) or directory.

## Example

<!-- example-cost: trivial -->
```rust
use aprender::bundle;
// See `cargo doc -p aprender-core --open` for full API reference.
```

## Full API

Run `cargo doc -p aprender-core --open` for the rendered rustdoc, or browse
[docs.rs/aprender](https://docs.rs/aprender) for the published version.
