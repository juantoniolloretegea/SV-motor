use std::{fs::{self,File,OpenOptions},io::Write,process::{Command,Stdio,Child,ExitStatus},time::{Duration,SystemTime,UNIX_EPOCH},thread,net::TcpStream};
use std::os::unix::process::CommandExt;
unsafe extern "C" { fn kill(pid:i32,sig:i32)->i32; }
const FIN:u64=1790145191; // 2026-09-23 06:33:11 UTC; cinco minutos para cierre exterior.
const REV:&str="6cee5e81ee83917806bbde320786a8fb61efebee";
fn now()->u64{SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_secs()}
fn event(s:&str){let mut f=OpenOptions::new().create(true).append(true).open("evidencias/SUCESOS.txt").unwrap(); writeln!(f,"{} {}",now(),s).unwrap(); println!("{} {}",now(),s);}
fn stop(c:&mut Child){unsafe{kill(-(c.id() as i32),15);} thread::sleep(Duration::from_secs(1)); if c.try_wait().ok().flatten().is_none(){unsafe{kill(-(c.id() as i32),9);}} let _=c.wait();}
fn wait(c:&mut Child,limit:u64)->Result<ExitStatus,String>{loop{if let Some(s)=c.try_wait().map_err(|e|e.to_string())?{return Ok(s)} if now()>=limit.min(FIN){stop(c);return Err("límite temporal".into())} thread::sleep(Duration::from_millis(250));}}
fn exec(name:&str,program:&str,args:&[&str],seconds:u64)->Result<(),String>{
 event(&format!("ORDEN {} {} {:?}",name,program,args));
 let f=File::create(format!("evidencias/{name}.log")).map_err(|e|e.to_string())?;
 let mut c=Command::new(program).args(args).stdout(Stdio::from(f.try_clone().unwrap())).stderr(Stdio::from(f)).process_group(0).spawn().map_err(|e|e.to_string())?;
 let s=wait(&mut c,now()+seconds)?;event(&format!("SALIDA {name} {s}"));if s.success(){Ok(())}else{Err(format!("{name}: {s}"))}
}
fn get(name:&str,url:&str,path:&str,hash:Option<&str>)->Result<(),String>{
 exec(name,"curl",&["--fail","--location","--silent","--show-error","--retry","0","--connect-timeout","20","--max-time","600","--output",path,url],610)?;
 if let Some(h)=hash{let out=Command::new("sha256sum").arg(path).output().map_err(|e|e.to_string())?;let txt=String::from_utf8_lossy(&out.stdout);event(&format!("SHA256 {}",txt.trim()));if !out.status.success()||txt.split_whitespace().next()!=Some(h){return Err(format!("huella no conforme: {path}"))}}
 Ok(())
}
fn run()->Result<(),String>{
 event("Corrección de argumento: retirada semilla no admitida por CPU; primera carga efectiva; pesos ya cotejados");
 let cwd=std::env::current_dir().unwrap();
 let args=["--token-source","none","serve","-m","modelo","--cpu","--dtype","bf16","--max-model-len","1024","--max-seq-len","1024","--max-seqs","1","--prefix-cache-n","0","--paged-attn","off","--host","127.0.0.1","--port","8089","--no-ui"];
 event(&format!("MOTOR ./motor/mistralrs {:?}",args));
 let f=File::create("evidencias/motor-ejecucion.log").unwrap();
 let mut server=Command::new("./motor/mistralrs").args(args).env("TIKTOKEN_ENCODINGS_BASE",cwd.join("harmony")).env("HF_HUB_OFFLINE","1").env_remove("MCP_CONFIG_PATH").stdout(Stdio::from(f.try_clone().unwrap())).stderr(Stdio::from(f)).process_group(0).spawn().map_err(|e|e.to_string())?;
 let mut peak=0u64;let mut ready=false;let load_end=(now()+600).min(FIN);
 while now()<load_end {
  if let Some(s)=server.try_wait().map_err(|e|e.to_string())?{event(&format!("MOTOR terminó durante carga: {s}"));return Err("carga del modelo fallida".into())}
  if let Ok(s)=fs::read_to_string(format!("/proc/{}/status",server.id())){for l in s.lines(){if l.starts_with("VmRSS:"){peak=peak.max(l.split_whitespace().nth(1).and_then(|x|x.parse::<u64>().ok()).unwrap_or(0)*1024)}}}
  if TcpStream::connect_timeout(&"127.0.0.1:8089".parse().unwrap(),Duration::from_millis(100)).is_ok(){ready=true;break}
  thread::sleep(Duration::from_millis(500));
 }
 if !ready{stop(&mut server);event(&format!("RSS carga muestreado {peak} bytes"));return Err("carga no terminada dentro de la ventana".into())}
 event("SERVICIO escuchando; una petición sintética");
 fs::write("evidencias/peticion.json",r#"{"model":"default","messages":[{"role":"system","content":"Responda en español formal y preciso, en una sola frase. No use herramientas."},{"role":"user","content":"Caso sintético: un inventario tiene tres elementos y se añaden dos. ¿Cuántos elementos hay en total?"}],"max_tokens":96,"temperature":0,"reasoning_effort":"low","stream":false}"#).unwrap();
 let response=exec("peticion-http","curl",&["--fail-with-body","--silent","--show-error","--max-time","300","--header","Content-Type: application/json","--data-binary","@evidencias/peticion.json","--output","evidencias/respuesta.json","--write-out","http=%{http_code} tiempo=%{time_total}\n","http://127.0.0.1:8089/v1/chat/completions"],310);
 stop(&mut server);event(&format!("MOTOR detenido; RSS muestreado solo durante carga {peak} bytes"));response?;
 event("PETICIÓN terminada; revisar respuesta.json antes de declarar conformidad");
 Ok(())
}
fn main(){let _=fs::create_dir_all("evidencias");match run(){Ok(())=>{event("FIN técnico del intento: revisar contenido y parada exterior");},Err(e)=>{event(&format!("FIN con incidencia: {e}"));std::process::exit(1)}}}

